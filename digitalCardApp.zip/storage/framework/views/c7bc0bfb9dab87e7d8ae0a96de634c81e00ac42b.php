

<?php $__env->startSection('title', 'Employees'); ?>
<?php $__env->startSection('employeeActive', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-12 mb-4 order-0">
                <div class="card">
                    <div class="card-body">
                        <div class="bcard_body col-5  border rounded">
                            <div class="py-5 px-2 d-flex justify-content-center align-item-center">
                                <div class="p-3">
                                    <img src="<?php echo e(asset('img/qrcodes/1646664151.png')); ?>" alt="">
                                </div>
                                <div class="mx-5 my-3" style="text-align:right; font-family:NovecentoSansW01-Book">
                                    <h3 style="font-weight: 600">Syed Suhaib Zia</h3>
                                    <h6 style="font-weight: 500">+923159408906</h6>
                                    <h6 style="font-weight: 500">suhaibzia786@gmail.com</h6>
                                </div>
                            </div>
                            <p class="text-center" style="word-spacing: 20%">www.suhaibzia.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suhai\OneDrive\Desktop\digitalCardApp\resources\views/employee/card_design.blade.php ENDPATH**/ ?>