

<?php $__env->startSection('title', 'All Cards'); ?>
<?php $__env->startSection('cardActive', 'active'); ?>
<?php $__env->startSection('customCss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/datatables-bs5/datatables.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/flatpickr/flatpickr.css')); ?>" />
    <style>
        .bussiness-card {
            width: 1050px;
            height: 600px;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-12 mb-4 order-0">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-4">
                            <div>
                                <h5 class="card-title text-primary">All Cards</h5>
                            </div>
                            
                        </div>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <?php echo e($message); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                </button>
                            </div>
                        <?php endif; ?>
                        <div class="card-datatable table-responsive">
                            <table class="dataList table border-top">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Photo</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Status</th>
                                        <th style="width: 120px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset('img/avatars/' . $employee->photo)); ?>"
                                                    style="max-width: 50px;border-radius: 10px;" alt="">
                                            </td>
                                            <td><?php echo e($employee->first_name); ?></td>
                                            <td><?php echo e($employee->last_name); ?></td>
                                            <td>
                                                <?php if($employee->status == 1): ?>
                                                    <i class="fas fa-check text-success"></i>
                                                <?php else: ?>
                                                    <i class="fas fa-times text-danger"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="javascript:void(0)"
                                                    onclick="openModal(<?php echo e($employee->employee_id); ?>)"
                                                    class="btn btn-primary btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-offset="0,4" data-bs-placement="top" data-bs-html="true"
                                                    title=""
                                                    data-bs-original-title="<i class='bx bx-bell bx-xs' ></i> <span>Print Card</span>"><i
                                                        class="bx bxs-id-card"></i></a>
                                            </td>
                                        </tr>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Content -->
    <!-- Modal -->
    <div class="modal fade" id="cardModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="addNewTitle">Print Card</h5>
                    <button type="button" onclick="$('#companyForm').reset()" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="business-card">
                        <img src="<?php echo e(asset('img/card.png')); ?>" class="m-auto"
                            style="width: 700px; border:1px solid black" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
    <script src="<?php echo e(asset('vendor/libs/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-responsive/datatables.responsive.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-buttons/datatables-buttons.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/jszip/jszip.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/pdfmake/pdfmake.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-buttons/buttons.html5.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/datatables-buttons/buttons.print.js')); ?>"></script>
    <!-- Flat Picker -->
    <script src="<?php echo e(asset('vendor/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/libs/flatpickr/flatpickr.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('.dataList').DataTable();
        })

        function openModal(employee_id) {
            $('#cardModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suhai\OneDrive\Desktop\digitalCardApp\resources\views/card/index.blade.php ENDPATH**/ ?>