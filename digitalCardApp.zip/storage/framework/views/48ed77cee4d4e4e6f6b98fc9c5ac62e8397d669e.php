

<?php $__env->startSection('title', 'Business Card'); ?>

<?php $__env->startSection('content'); ?>
    
    <style>
        .bcard div {
            border: 1px solid black;
            margin-top: 30px
                /* border-radius: 10px; */
        }

    </style>
    <div class="vh-100 card rounded-0 m-auto" style="width: 70%">
        <div class="card-header rounded-0 border-bottom d-flex justify-content-center align-items-center">
            <button class="btn btn-primary mx-3">Download</button>
            <button class="btn btn-success">Print</button>
        </div>
        <div class="card-body">
            <div class="bcard d-flex justify-content-center m-auto">
                <div class="logside d-flex flex-column justify-content-center align-items-center"
                    style="background-color: <?php echo e($card[0]->card_color); ?>; height:300px; width:40%;border-top-left-radius: 10px;border-bottom-left-radius: 10px">
                    <img src="<?php echo e(asset('img/logo') . '/' . $card[0]->logo); ?>" style="max-width: 120px" alt="">
                    <h4 class="text-uppercase"><?php echo e($card[0]->name); ?></h4>
                    <h6 class="text-uppercase"><?php echo e($card[0]->slogan); ?></h6>
                </div>
                <div class="contentside d-flex flex-column justify-content-center align-items-center"
                    style="width:40%;border-top-right-radius: 10px;border-bottom-right-radius: 10px">
                    <h4><?php echo e($card[0]->first_name . ' ' . $card[0]->last_name); ?></h4>
                    <p class="text-center my-3">
                        <?php echo e($card[0]->office_phone); ?> <br>
                        <?php echo e($card[0]->email); ?> <br>
                        <?php echo e($card[0]->website); ?>

                    </p>
                    <p class="text-center">
                        <?php echo e($card[0]->name); ?> <br>
                        <?php echo e($card[0]->address_line1 . ' ' . $card[0]->address_line2); ?> <br>
                        <?php echo e($card[0]->city . ', ' . $card[0]->state); ?> <br>
                        <?php echo e($card[0]->zip_code); ?> <br>
                        <?php echo e($card[0]->country); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.card_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suhai\OneDrive\Desktop\ Swiss Tech (Innvo Byte)\digitalCardApp\resources\views/employee/card_design.blade.php ENDPATH**/ ?>