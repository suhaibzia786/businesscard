<!-- Menu -->
<aside id="layout-menu" class="layout-menu-horizontal menu-horizontal  menu bg-menu-theme flex-grow-0">
    <div class="container-xxl d-flex h-100">
        <ul class="menu-inner">
            <!-- Dashboards -->
            <li class="menu-item <?php echo $__env->yieldContent('dashboardActive'); ?>">
                <a href="<?php echo e(route('dashboard.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-home-circle"></i>
                    <div data-i18n="Dashboards">Dashboards</div>
                </a>
            </li>
            <li class="menu-item <?php echo $__env->yieldContent('companyActive'); ?>">
                <a href="<?php echo e(route('company.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-building"></i>
                    <div data-i18n="Company">Company</div>
                </a>
            </li>
            <li class="menu-item <?php echo $__env->yieldContent('employeeActive'); ?>">
                <a href="<?php echo e(route('employee.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-user"></i>
                    <div data-i18n="Employees">Employees</div>
                </a>
            </li>
            <li class="menu-item <?php echo $__env->yieldContent('subscriptionActive'); ?>">
                <a href="<?php echo e(route('company.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-purchase-tag-alt"></i>
                    <div data-i18n="Subscriptions">Subscriptions</div>
                </a>
            </li>
            
        </ul>
    </div>
</aside>
<!-- / Menu -->
<?php /**PATH C:\Users\suhai\OneDrive\Desktop\digitalCardApp\resources\views/partials/nav.blade.php ENDPATH**/ ?>