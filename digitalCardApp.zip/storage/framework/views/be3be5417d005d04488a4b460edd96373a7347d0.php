

<?php $__env->startSection('content'); ?>
    
    <div class="card vh-100" style="border-radius: 0 !important">
        <div class="card-body d-flex flex-column h-75 text-center justify-content-center align-items-center">
            <img src="<?php echo e(asset('img/logo') . '/' . $company[0]->logo); ?>" style="max-width: 150px" alt="">
            <h2 class="text-uppercase"><?php echo e($company[0]->name); ?></h2>
            <h4 class="text-uppercase"><?php echo e($company[0]->slogan); ?></h4>
        </div>
        <div class="card-footer d-flex flex-column h-25 justify-content-center align-items-center"
            style="background-color: #444544;border-radius: 0 !important; font-size:12px">
            <h6 class="text-white" style="margin-top:30px"><?php echo e($company[0]->name); ?></h6>
            <p class="text-center text-white"><?php echo e($company[0]->address_line1 . ' ' . $company[0]->address_line2); ?> <br>
                <?php echo e($company[0]->city . ', ' . $company[0]->state); ?> <br>
                <?php echo e($company[0]->zip_code); ?></p>
            <small>&copy;<?php echo e(date('Y') . ' ' . $company[0]->name); ?>. All Rights Reserved</small>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.clp_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suhai\OneDrive\Desktop\ Swiss Tech (Innvo Byte)\digitalCardApp\resources\views/clp.blade.php ENDPATH**/ ?>