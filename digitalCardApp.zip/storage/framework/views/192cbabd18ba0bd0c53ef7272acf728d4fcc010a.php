

<?php $__env->startSection('title', 'Dashbard'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-12 mb-4 order-0">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title text-primary">Dashboard</h5>
                    </div>
                </div>
            </div>
        </div>



    </div>
    <!--/ Content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.super_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\suhai\OneDrive\Desktop\digitalCardApp\resources\views/super/dashboard.blade.php ENDPATH**/ ?>